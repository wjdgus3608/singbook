# Handoff: 내 노래책 (노래방 키 기록 앱) v1 UI

## Overview
코인노래방에서 곡마다 내 음정에 맞는 키 오프셋(-7~+7)을 기록하는 개인 노래책 앱.
- 프레임워크: **Flutter (Dart)**, Android + iOS
- 저장: SQLite (sqflite), 로컬 전용 (백엔드 없음)
- 곡 검색/메타데이터: Spotify API (Client Credentials)
- 전주 인식: ACRCloud

## About the Design Files
`노래책 UI.dc.html`은 HTML로 만든 **디자인 레퍼런스**다. 그대로 쓰는 코드가 아니므로 Flutter 위젯으로 다시 구현해야 한다. 브라우저로 열어서 보면 되고, 같은 폴더에 `support.js`가 있어야 열린다.

**구현 기준은 1안(1a–1e)이다.** 2a의 키 배지는 이미 1a 내 목록에 반영돼 있다. 2a–2d는 참고용 시안이라 구현하지 않는다.

## Fidelity
High-fidelity. 색·타이포·간격·radius는 최종값이고, 360dp 폭을 기준으로 잡았다. 앨범아트 자리의 줄무늬는 플레이스홀더라서 실제로는 Spotify `album.images` URL을 넣는다.

## Design Tokens

### Colors
```
bg            #0B0B0F   화면 배경
surface       #13131A   카드, 키 설정 패널, 메모 박스, 설정 그룹
surface2      #16161D   검색 필드, 정렬/최근검색 칩, 인식 결과 시트
surface3      #1F1F28   스테퍼 버튼, 보조 버튼(닫기)
navBg         #0E0E13   하단 탭바
divider       #1A1A22   탭바 상단선, 구분선
dividerList   #1C1C25   설정 리스트 구분선
border        #2A2A35   미선택 칩, 시트 테두리
borderDashed  #3A3A46   태그 추가 [+] (dashed)
text          #EDEDF2
textSub       #C8C8D2   칩 텍스트, 메모
textMuted     #8A8A99   아티스트, 섹션 라벨
textFaint     #6E6E7C   placeholder, 비활성 탭, 캡션
textDim       #5C5C6A   슬라이더 눈금 라벨, 0점 마커
accent        #8B7BFF   키 숫자, 기본 버튼, 활성 탭
accentSoft    #B3A8FF   태그 텍스트, 배지 보조 텍스트
accentTint    rgba(139,123,255,0.14)  키 배지 배경 (필터 칩은 0.16)
accentLine    rgba(139,123,255,0.40)  키 배지 테두리
onAccent      #0B0B0F   accent 위 텍스트
danger        #FF6B7A   전체 삭제
```
Glow:
- 상세 화면 키 숫자: `shadow 0 0 24 rgba(139,123,255,.5)`
- 인식 마이크 버튼: `0 0 48 rgba(139,123,255,.55)`
- 슬라이더 thumb: 4px `rgba(139,123,255,.35)` 링

### Typography
- UI 전체: **Pretendard** (Variable)
- 숫자 전용: **JetBrains Mono**. 키 오프셋, 키 이름(E, C#m), 시간, 버전, 태그 개수에 쓴다.
- 스케일 (size/weight):
  - 24/800 앱 타이틀
  - 20/700 화면 타이틀, 상세 곡명
  - 17/700 인식 결과 곡명
  - 16/700 저장 버튼
  - 15/600 리스트 곡명
  - 15/400 설정 항목
  - 14 본문, 메모 (line-height 1.5)
  - 13 아티스트, 칩, 섹션 라벨
  - 12 태그, 탭 라벨, 캡션
  - 10 키 배지 보조 텍스트
- 키 숫자: 목록 배지는 19/800 Mono, 상세는 52/800 Mono (line-height 1)

### Radius / Spacing
- radius:
  - 칩 16 (full)
  - 버튼 12 / 저장 14
  - 검색필드 12
  - 패널 16
  - 시트 20
  - 앨범아트 8(목록) / 12(상세)
  - 키 배지 12
- 화면 좌우 패딩 20. 리스트는 컨테이너 12 + 아이템 내부 8.
- 터치 타깃은 최소 44 (아이콘 버튼 44×44).
- 높이:
  - 칩 32 (최근검색은 30)
  - 검색필드 44 (목록) / 48 (검색 탭)
  - 버튼 48–52
  - 탭바 72
- 칩 텍스트는 한 줄로 두고, 칩이 줄어들지 않게 한다.

### Icons
Material Symbols Rounded (Flutter `Icons.*_rounded`): settings, search, expand_more, sell, library_music, mic, add, check, cancel, arrow_back, delete, remove, close, download, delete_forever. 활성 탭 아이콘은 filled 스타일을 쓴다.

## Navigation
- 하단 탭 3개: `[내 목록] [검색] [인식]`
- 스택 화면 2개: 곡 상세/편집, 설정. 스택 화면에는 탭바가 없다.
- 진입 흐름:
  - 검색 결과 [+추가] → 곡 상세 (신규)
  - 내 목록 곡 탭 → 곡 상세 (편집)
  - 인식 완료 [내 목록에 추가] → 곡 상세 (신규, 곡 정보 자동 입력)
  - 내 목록 헤더 ⚙ → 설정

탭바 공통:
- 높이 72, 배경 navBg, 상단 1px divider
- 아이콘 24 + 라벨 12, gap 4
- 활성 탭: accent 색 + 라벨 600
- 비활성 탭: textFaint

## Screens

### ① 내 목록 (1a)
- **헤더:** "내 노래책" 24/800. 우측 settings 아이콘(textMuted, 44×44)을 누르면 설정으로 이동.
- **검색 필드:** 44h, surface2, r12, 좌측 search 아이콘 20, placeholder "내 목록 검색". 곡명과 아티스트로 로컬 필터링한다.
- **필터 줄 (gap 8):**
  - 정렬 칩 "최근 추가 ▾" (surface2). 옵션 제안: 최근 추가 / 곡명순 / 키순.
  - 태그 칩 "sell 태그" (1px border). 누르면 태그 선택 시트가 열린다.
  - 선택된 태그 칩 "#단골" (accentTint 배경, accentSoft 텍스트). 탭하면 해제된다.
- **리스트 아이템 (padding 10×8, gap 12):**
  - 앨범아트 52×52 r8
  - 텍스트 컬럼 (gap 2): 곡명 15/600, 아티스트 13 textMuted, 태그 12 accentSoft (`#단골` 형식)
  - **키 배지 (2a 적용):** 우측 52×52, r12
    - offset ≠ 0: accentTint 배경 + 1px accentLine 테두리. 위에 오프셋 Mono 19/800 accent (`-2`, `+1`, 양수는 `+` 표시), 아래에 **변환된 키 이름** Mono 10 accentSoft (예: `E`, `C#m`), gap 3.
    - offset = 0: 배경 #1A1A22, 테두리 없음. 위에 `0`(textFaint), 아래에 "원키"(Pretendard 10).
- 빈 상태는 디자인에 없다. 문구 제안: "아직 저장한 곡이 없어요" + 검색/인식 탭 안내.

### ② 검색 (1b)
- **검색 필드:** 48h, surface2, 포커스 시 1px accent 테두리. search 아이콘 accent, 입력이 있으면 우측에 cancel(clear) 아이콘.
- **최근 검색:** 캡션 12 textFaint "최근 검색". 칩 30h(surface2, textSub)을 탭하면 재검색한다. 최대 N개를 로컬에 저장한다.
- 구분선 1px divider (좌우 20 inset)
- **결과 아이템:**
  - 앨범아트 52
  - 곡명 15/600
  - "아티스트 · 앨범" 13 textMuted
  - 우측 버튼:
    - 미저장: `+ 추가` pill 32h, accent 배경, onAccent 13/700
    - 이미 저장됨: `✓ 저장됨` pill, 배경 #1C1C25, textFaint, 비활성. 누르면 곡 상세(편집)로 가도록 해도 된다.
- Spotify search: `type=track`, `market=KR` 권장, debounce 300ms 정도.

### ③ 인식 (1c)
- 타이틀 "인식" 20/700 가운데 정렬
- **마이크 버튼:**
  - 132×132 원, accent 배경, glow
  - 바깥에 168 원 링 (1px, accent 25%)
  - 아이콘 mic filled 56, onAccent
- 버튼 아래 점 3개 (8×8, accent, 불투명도 1/.5/.25)와 안내문 "전주가 나올 때 탭하세요" 14 textMuted
- **상태:**
  - idle: 버튼과 안내문
  - listening: 점 3개가 순차 pulse(1.2s, 0.2s 간격)하고 안내문이 "듣고 있어요"로 바뀐다. 녹음은 약 10–12초.
  - 완료: 하단에 결과 시트가 나타난다 (아래 참고).
  - 실패: 시트에 "곡을 찾지 못했어요" + 다시 시도 (디자인 없음, 같은 시트 스타일)
- **결과 시트:**
  - 좌우 margin 12, 하단 12, surface2, 1px border, r20, padding 16, gap 14
  - 캡션 "인식 완료" 12/600 accentSoft
  - 앨범아트 60 r8 + 곡명 17/700 + "아티스트 · 앨범" 13
  - 버튼: [내 목록에 추가] flex 48h accent / [닫기] 88w 48h surface3
- ACRCloud 결과의 `external_metadata.spotify.track.id`로 Spotify 트랙을 매칭한다.

### ④ 곡 상세/편집 (1d)
- **상단:** arrow_back(좌), delete(우, textMuted). 삭제하기 전에 확인 다이얼로그를 띄운다. 신규 곡이면 삭제 버튼을 숨긴다.
- **곡 정보 (가운데 정렬, gap 6):**
  - 앨범아트 120×120 r12
  - 곡명 20/700
  - 아티스트 14 textMuted
  - "원키 **F#** 장조" 13 (키 이름은 Mono textSub)
- **키 설정 패널 (surface, r16, padding 18×16, margin 0 16, gap 14):**
  - 라벨 "내 키" 13 textMuted
  - 스테퍼 행 (space-between):
    - [−] 52×52 원 surface3 (remove 28)
    - 가운데 오프셋 Mono 52/800 accent + glow, 아래에 변환 키 "**E** 장조" 13
    - [+] 52×52 원 surface3 (add 28)
  - 슬라이더:
    - 트랙 4h #24242E
    - 0 지점부터 현재값까지 accent 채움
    - 0 위치에 2×12 마커 (textDim)
    - thumb 18 원 #EDEDF2 + 4px accent 35% 링
    - 15 step(-7..+7), 햅틱 권장
  - 눈금 라벨 `-7 · 0 · +7` Mono 11 textDim
  - 값이 0이면 숫자를 textFaint로 표시하고 "원키"라고 적는 것을 권장한다.
- **태그:**
  - 라벨 13 textMuted
  - 칩 32h
    - 선택: accent 배경, onAccent 13/700
    - 미선택: 1px border, textSub
  - 마지막에 [+] 32×32 dashed 칩: 누르면 새 태그 입력 다이얼로그가 뜬다.
  - flex-wrap, gap 8
- **메모:** 라벨과 surface r12 박스(padding 12×14, 14/1.5), 멀티라인 TextField
- **저장 버튼:** 하단 padding 16, 52h, r14, accent 16/700
  - 저장 시 `updated_at`을 갱신한다.
  - 신규 곡이면 insert 후 내 목록으로 돌아간다.

### ⑤ 설정 (1e)
- 헤더: arrow_back + "설정" 20/700
- **태그 관리:**
  - 섹션 캡션 12 textFaint
  - surface r16 그룹. 행 52h: 태그명 15 + 사용 곡 수 Mono 12 textFaint, 우측 close 아이콘으로 삭제(확인)
  - 마지막 행 "+ 새 태그" accentSoft
  - 구분선 1px #1C1C25
- **데이터:**
  - 행 56h, 아이콘 22
  - "데이터 내보내기" + 우측 "JSON" Mono 12 → share sheet로 파일 공유
  - "전체 삭제" danger 색 → 2단계 확인
- 하단: "앱 버전" 좌 / `1.0.0` Mono 우, 13 textFaint

## 키 계산 로직
- `displayKey = transpose(originalKey, offset)`, 반음 단위
- Spotify Audio Features: `key` 0–11 (C=0), `mode` 1=장조 0=단조
- 표기는 샵 기준: `C C# D D# E F F# G G# A A# B`
  - 단조는 뒤에 `m`을 붙이고 (배지: `C#m`), 상세에서는 "단조"로 쓴다.
- 예: F#(6) 장조 + (-2) → 4 = **E 장조**
- 원키 정보가 없으면 배지 아래 텍스트와 "원키/변환 키" 행을 숨기고 오프셋만 보여준다.
- ⚠ Spotify Audio Features 엔드포인트는 신규 앱에서 제한될 수 있다. 개발 초기에 확인하고, 원키는 없어도 동작하는 선택값으로 설계한다.

## State / Data
```sql
songs (
  id          TEXT PRIMARY KEY,  -- Spotify track ID
  title       TEXT,
  artist      TEXT,
  album_art   TEXT,
  key_offset  INTEGER,           -- -7 ~ +7
  memo        TEXT,
  tags        TEXT,              -- JSON 배열
  updated_at  INTEGER
)
```
원키 표시를 위해 다음 컬럼 추가를 권장한다:
- `original_key INTEGER NULL` (0–11)
- `original_mode INTEGER NULL`
- `album TEXT`
- `created_at INTEGER` (최근 추가 정렬용)

태그 마스터 목록(설정의 태그 관리)은 `tags` 테이블을 따로 두거나 shared_preferences에 저장한다. 기본값은 단골 / 고음주의 / 쉬움.

## Files
- `노래책 UI.dc.html`: 디자인 레퍼런스. 1a–1e가 구현 대상이고 2a–2d는 참고용 시안이다.
- `support.js`: HTML 레퍼런스를 여는 데 필요한 런타임 (구현과 무관)
